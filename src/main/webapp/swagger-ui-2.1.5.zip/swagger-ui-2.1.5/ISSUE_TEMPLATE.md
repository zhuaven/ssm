When reporting a bug, please provide the following details:
- swagger-ui version
- a swagger file reproducing the issue
